import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor


data = pd.read_csv("exercise1.csv")


print(data.head())
print(data.describe())


print(data.isnull().sum())


from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
data['Gender'] = le.fit_transform(data['Gender'].values)


X = data[['Duration', 'Heart_Rate', 'Body_Temp']]
y = data['Calories']


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


lin_model = LinearRegression()
lin_model.fit(X_train, y_train)
y_pred_lin = lin_model.predict(X_test)


rf_model = RandomForestRegressor(random_state=42)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)


plt.figure(dpi=125)
sns.regplot(x=y_test, y=y_pred_lin, scatter_kws={"color": "blue"}, line_kws={"color": "red"})
plt.xlabel('True Values')
plt.ylabel('Predicted Values')
plt.title('Linear Regression: True vs Predicted Values')
plt.show()


plt.figure(dpi=125)
sns.regplot(x=y_test, y=y_pred_rf, scatter_kws={"color": "green"}, line_kws={"color": "orange"})
plt.xlabel('True Values')
plt.ylabel('Predicted Values')
plt.title('Random Forest Regression: True vs Predicted Values')
plt.show()

data = data.drop(columns=['User_ID34r'])
plt.figure(dpi=125)
sns.heatmap(data.corr(numeric_only=True).round(2), annot=True)
plt.title('Feature Correlation Matrix')
plt.show()


variables = ['Height', 'Gender', 'Heart_Rate', 'Duration']
for var in variables:
    plt.figure(dpi=125)
    plt.scatter(data[var], data['Calories'])
    plt.xlabel(var)
    plt.ylabel('Calories')
    plt.title(f'{var} vs Calories')
    plt.show()


mse_lin = mean_squared_error(y_test, y_pred_lin)
r2_lin = r2_score(y_test, y_pred_lin)

mse_rf = mean_squared_error(y_test, y_pred_rf)
r2_rf = r2_score(y_test, y_pred_rf)

print("Linear Regression - Mean Squared Error:", mse_lin)
print("Linear Regression - R^2 Score:", r2_lin)

print("Random Forest - Mean Squared Error:", mse_rf)
print("Random Forest - R^2 Score:", r2_rf)
